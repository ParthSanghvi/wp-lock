jQuery(document).ready(function ($) {
    'use strict';
    $(document).on('click', '.all-pages', function(){
        var checkfield = $(".all-pages").val();
        $.ajax({
            dataType: "JSON",
            url: WPaAjax.ajaxurl,
            type: 'GET',
            data: {action: 'wp_lock_settings', 'check_field': checkfield},
            success: function (response) {

            }
        });

    });
});
