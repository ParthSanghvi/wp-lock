<?php

/**
 * Fired during plugin activation
 *
 * @link       multidots
 * @since      1.0.0
 *
 * @package    Wp_Lock
 * @subpackage Wp_Lock/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wp_Lock
 * @subpackage Wp_Lock/includes
 * @author     Multidots <info@multidots.com>
 */
class Wp_Lock_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
