<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       multidots
 * @since      1.0.0
 *
 * @package    Wp_Lock
 * @subpackage Wp_Lock/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wp_Lock
 * @subpackage Wp_Lock/admin
 * @author     Multidots <info@multidots.com>
 */
class Wp_Lock_Admin
{

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string $plugin_name The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string $version The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string $plugin_name The name of this plugin.
     * @param      string $version The version of this plugin.
     */
    public function __construct($plugin_name, $version)
    {

        $this->plugin_name = $plugin_name;
        $this->version = $version;

    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_styles()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Wp_Lock_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Wp_Lock_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/wp-lock-admin.css', array(), $this->version, 'all');
        wp_enqueue_style('bootstrap-min', plugin_dir_url(__FILE__) . 'css/bootstrap.min.css', array(), $this->version, 'all');

    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Wp_Lock_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Wp_Lock_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/wp-lock-admin.js', array('jquery'), $this->version, false);
        wp_enqueue_script('bootstrap', plugin_dir_url(__FILE__) . 'js/bootstrap.min.js', array('jquery'), $this->version, false);
        wp_localize_script(
            $this->plugin_name,
            'WPaAjax',
            array(
                'ajaxurl' => admin_url('admin-ajax.php')
            )
        );

    }

    public function plugin_settings()
    {
        add_menu_page(
            __('Custom Menu Title', 'textdomain'),
            'WP Lock Settings',
            'manage_options',
            'wp-lock-settings',
            array(
                $this,
                'wp_lock_settings'
            )
        );
    }

    public function wp_lock_settings()
    {
        global $post;
        $checkfield = maybe_unserialize(get_post_meta($post->ID, "checkfield", true));
        $pages = get_pages();
        $get_pages = get_option('selected_pages');
        $get_pages = maybe_unserialize($get_pages);
        ?>
        <form method="post" action="">
            <table border="0">
                <tr>
                    <td>
                        <h3>Select Pages to Unlock</h3>
                        <hr>
                        <div class="row">
                            <?php foreach ($pages
                            as $page) { ?>
                            <div class="col-sm-4">
                                <input id="page_<?php echo $page->ID; ?>" class="all-pages"
                                       type="checkbox" <?php if (in_array($page->ID, $get_pages)){ ?> checked
                                       <?php } ?>name="checkfield[]"
                                       value="<?php echo $page->ID; ?>" <?php if (in_array($page->ID, (array)$checkfield)) { ?><?php } ?>/>
                                <label for="page_<?php echo $page->ID; ?>"><?php echo $page->post_title; ?></label> <br>
                            </div>
                        </div>

                        <?php
                        }
                        ?>
                        <?php
                        if (isset($_POST['checkfield'])) {
                            $selected_pages = $_POST['checkfield'];
                            if(!empty($selected_pages))
                            update_option('selected_pages', $selected_pages);
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        <?php
                        // $get_custom_slugs = get_option('custom_slugs');
                        //                        $get_custom_slugs = maybe_unserialize($get_custom_slugs);
                        //                        $slug = implode(' ', $get_custom_slugs);
                        if (isset($_POST['urls'])) {
                            $entered_urls = $_POST['urls'];
//                            $entered_urls_as_array = explode("\n", str_replace("\r", "", $entered_urls));
//                            $entered_urls_as_array = maybe_serialize($entered_urls_as_array);
//                            if ($opt_entered_urls) {
                            update_option('custom_slugs', $entered_urls);
//                            } else {
//                                add_option('custom_slugs', $entered_urls_as_array);
//                            }
                        }
                        ?>
                        <div class="row">
                            <div class="col-sm-4">
                                <h3>Enter the Slugs to unlock the pages</h3>
                                <span>Note : Please add every slug with comma(,) seprated.</span>
                                <hr>
                                <textarea rows="4" cols="150"
                                          name="urls"><?php echo get_option('custom_slugs');
                                    ?></textarea></div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h3>Enter the Custom Message</h3>
                        <hr>
                        <?php
                        $content = get_option('custom_message');
                        $editor_id = 'mycustomeditor';
                        if (isset($_POST['mycustomeditor'])) {
                            update_option('custom_message', wp_kses_post($_POST['mycustomeditor']));
                        }
                        $settings = array(
                            'editor_height' => 10, // In pixels, takes precedence and has no default value
                            'textarea_rows' => 10,  // Has no visible effect if editor_height is set, default is 20
                        );
                        wp_editor($content, $editor_id,$settings);
                        ?>
                    </td>
                </tr>
            </table>
            <br>
            <input type="submit" name="save_entered_urls" class="button button-primary button-large">
        </form>
        <?php

    }
}
