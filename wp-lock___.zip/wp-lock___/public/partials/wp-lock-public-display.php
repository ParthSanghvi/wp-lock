<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       multidots
 * @since      1.0.0
 *
 * @package    Wp_Lock
 * @subpackage Wp_Lock/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
